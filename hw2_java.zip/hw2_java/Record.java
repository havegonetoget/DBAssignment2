import java.io.IOException;

public class Record {

  private boolean empty;

  public String college_ID;
  public String state;
  public String city;
  public String name;

  public Record() {
    empty = true;
  }

  public void updateFields(String[] fields) throws IOException {
    if (fields.length == 4) {
      this.college_ID = fields[0].trim();
      this.state = fields[1].trim();
      this.city = fields[2].trim();
      this.name = fields[3].trim();
      empty = false;
    } else
      throw new IOException();
  }

  public boolean isEmpty() {
    return empty;
  }

  public String toString() {
    return "College ID: " + this.college_ID +
        ", State: " + this.state +
        ", City: " + this.city +
        ", Name: " + this.name;
  }

}
